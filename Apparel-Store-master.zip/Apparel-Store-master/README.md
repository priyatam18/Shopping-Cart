# Karthik Venkataramana Pemmaraju <br/>

A secure E-Commerce website constructed using PHP 7 (OOP). <br/>
Feel free to reach me at karthik.venkat.p@gmail.com in case if you notice any bugs or security fixes.<br/>
# Collaborators:<br/>
    Obianuju Okafor (oco0017)<br/> 
    Isaac Samuel Raj Boddu (ib0076)<br/>
 <br/>
site url: https://apparels.000webhostapp.com/index.php <br/>

# Test User credentials<br/>
user username: karthik@gmail.com<br/>
user password: Karthik@123<br/>

# Test PayPal credentials<br/>
paypal username: group5se_buyer@gmail.com<br/>
password: Group1@Hackers<br/>
  
# Test Admin credentials<br/>
admin username: Group1ApparelAdmin@my.apparel.net<br/>
admin password: !)(@5450@Hackers<br/>

![Preview](https://github.com/karthikVenkataramana/Apparel-Store/blob/master/preview.PNG) <br/><br/><br/>
![Cart](https://github.com/karthikVenkataramana/Apparel-Store/blob/master/cart.PNG) <br/>
